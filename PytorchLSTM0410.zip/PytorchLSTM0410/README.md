# Pytorch-LSTMandLSTMCell
PytorchのLSTMとLSTMCellを実装してみた。
