# -*- coding: utf-8 -*-
# パラメータの定義
#データ何プロットを学習するか
N = 100
#データの数
DataNumber = 1
#入出力の次元
in_size = 1
out_size = 1
#中間ノードの次元
Node = 50
#学習回数
EPOCH_NUM = 500
#バッチサイズ
BATCH_SIZE = 1

